﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.Diagnostics.CodeAnalysis;

namespace Crypto_Project.Models
{
    public class SaltedHash
    {
        public string Text { get; set; }
        [ValidateNever]
        [AllowNull]
        public string SHAHash { get; set; }
        [ValidateNever]
        [AllowNull]
        public string Salt { get; set; }
        [ValidateNever]
        [AllowNull]
        public string Hash { get; set; }
    }
}
