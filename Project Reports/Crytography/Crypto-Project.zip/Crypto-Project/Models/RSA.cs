﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.Diagnostics.CodeAnalysis;
using System.Numerics;

namespace Crypto_Project.Models
{
    public class RSA
    {
        public int p {  get; set; }
        public int q { get; set; }
        [ValidateNever]
        [AllowNull]
        public Tuple<int, int> publicKey { get; set; }
        [ValidateNever]
        [AllowNull]
        public Tuple<int, int> privateKey { get; set; }
    }
}
