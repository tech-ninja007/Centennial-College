﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.Diagnostics.CodeAnalysis;

namespace Crypto_Project.Models
{
    public class RSA_ED
    {
        [ValidateNever]
        [AllowNull] 
        public string message { get; set; }
        [ValidateNever]
        [AllowNull]
        public string cipher { get; set; }
        
        public string key { get; set; }
    }
}
