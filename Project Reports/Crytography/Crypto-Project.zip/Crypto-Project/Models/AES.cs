﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.Diagnostics.CodeAnalysis;

namespace Crypto_Project.Models
{
    public class AES
    {
        public string Key { get; set; }
        [ValidateNever]
        [AllowNull]
        public string Text { get; set; }
        [ValidateNever]
        [AllowNull]
        public string Cipher { get; set; }

    }
}
//using System;
//using System.Numerics;
//using System.Security.Cryptography;
//using System.Text;

//namespace AESExample
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Console.WriteLine("Enter the AES key (32 characters): ");
//            string keyInput = Console.ReadLine();

            //if (keyInput.Length != 32)
            //{
            //    if (keyInput.Length < 32)
            //    {
            //        Console.WriteLine("Invalid key length. The key must be 32 characters long.");
            //        return;
            //    }
            //    if (keyInput.Length > 32)
            //    {
            //        keyInput = keyInput.Substring(0, 32);
            //    }

            //}

//            byte[] key = Encoding.UTF8.GetBytes(keyInput);

//            Aes aes = Aes.Create();
//            aes.KeySize = 256;
//            aes.Mode = CipherMode.CBC;
//            aes.Key = key;
//            byte[] fixedIV = Encoding.UTF8.GetBytes("1234567890123456");
//            aes.IV = fixedIV;

//            string plaintext = "Hello";
//            byte[] ciphertext;

//            using (ICryptoTransform encryptor = aes.CreateEncryptor())
//            {
//                byte[] plaintextBytes = Encoding.UTF8.GetBytes(plaintext);
//                ciphertext = encryptor.TransformFinalBlock(plaintextBytes, 0, plaintextBytes.Length);
//            }

//            string decryptedText;

//            using (ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV))
//            {
//                byte[] decryptedBytes = decryptor.TransformFinalBlock(ciphertext, 0, ciphertext.Length);
//                decryptedText = Encoding.UTF8.GetString(decryptedBytes);
//            }

//            Console.WriteLine($"Plaintext: {plaintext}");
//            Console.WriteLine($"Ciphertext: {Convert.ToBase64String(ciphertext)}");
//            Console.WriteLine($"Decrypted text: {decryptedText}");
//        }
//    }
//}
