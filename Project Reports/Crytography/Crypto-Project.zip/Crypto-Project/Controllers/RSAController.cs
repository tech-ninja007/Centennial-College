﻿using Crypto_Project.Models;
using Microsoft.AspNetCore.Mvc;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace Crypto_Project.Controllers
{
    public class RSAController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Index(RSA obj)
        {
            if(ModelState.IsValid)
            {
                Tuple<int, int> publicKey, privateKey;                
                publicKey = GenerateKeyPair(obj.p, obj.q);
                privateKey = Tuple.Create(MultiplicativeInverse(publicKey.Item1, (obj.p - 1) * (obj.q - 1)), publicKey.Item2);

                obj.publicKey = publicKey;
                obj.privateKey = privateKey;
                
            }
            return View(obj);
        }
        public IActionResult Encrypt()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Encrypt(RSA_ED obj)
        {
            if (ModelState.IsValid)
            {
                string inputText = obj.key.Replace(" ", "");

                string inputText2 = inputText.Substring(1, inputText.Length - 2);

                // Parse the input string to extract two integers
                string[] parts = inputText2.Split(',');
                
                int firstValue = int.Parse(parts[0]);
                int secondValue = int.Parse(parts[1]);

                // Create a Tuple<int, int> with the parsed values
                Tuple<int, int> Key = Tuple.Create(firstValue, secondValue);
                
                int[] encryptedMsg = Encrypt(Key, obj.message);
                obj.cipher = string.Join(" ", encryptedMsg);
            }
            return View(obj);
        }
        public IActionResult Decrypt()
        {

            return View();
        }
        [HttpPost]
        public IActionResult Decrypt(RSA_ED obj)
        {
            if (ModelState.IsValid)
            {
                string inputText = obj.key.Replace(" ","");
                string inputText2 = inputText.Substring(1, inputText.Length - 2);

                // Parse the input string to extract two integers
                string[] parts = inputText2.Split(',');

                int firstValue = int.Parse(parts[0]);
                int secondValue = int.Parse(parts[1]);

                // Create a Tuple<int, int> with the parsed values
                Tuple<int, int> Key = Tuple.Create(firstValue, secondValue);
                
                string[] stringArray = obj.cipher.Split(' ');

                // Convert each string element to an integer and store in an int array
                int[] cipherArray = Array.ConvertAll(stringArray, int.Parse);

                obj.message = Decrypt(Key, cipherArray);

            }
            return View(obj);
        }

        //RSA
        static Random random = new Random();

        static int GCD(int a, int b)
        {
            while (b != 0)
            {
                int temp = b;
                b = a % b;
                a = temp;
            }
            return a;
        }

        static int MultiplicativeInverse(int x, int y)
        {
            int mudulator = y;
            int r1 = y;
            int r2 = x;
            int t1 = 0;
            int t2 = 1;

            while (r2 > 0)
            {
                int q = r1 / r2;
                int r = r1 - q * r2;
                r1 = r2;
                r2 = r;
                int t = t1 - q * t2;
                t1 = t2;
                t2 = t;
            }

            if (r1 == 1)
            {
                if (t1 > 0)
                {
                    return t1;
                }
                else
                {
                    return t1 + mudulator;
                }
            }

            throw new ArithmeticException("No multiplicative inverse exists.");
        }

        static bool IsPrime(int num)
        {
            if (num == 2)
            {
                return true;
            }

            if (num < 2 || num % 2 == 0)
            {
                return false;
            }

            for (int n = 3; n <= Math.Sqrt(num); n += 2)
            {
                if (num % n == 0)
                {
                    return false;
                }
            }

            return true;
        }

        static Tuple<int, int> GenerateKeyPair(int p, int q)
        {
            if (!(IsPrime(p) && IsPrime(q)))
            {
                throw new ArgumentException("Both numbers must be prime.");
            }
            else if (p == q)
            {
                throw new ArgumentException("p and q cannot be equal");
            }

            int n = p * q;
            int phi = (p - 1) * (q - 1);
            int e = random.Next(2, phi);

            int g = GCD(e, phi);
            while (g != 1)
            {
                e = random.Next(2, phi);
                g = GCD(e, phi);
            }

            int d = MultiplicativeInverse(e, phi);

            return Tuple.Create(e, n);
        }

        static int[] Encrypt(Tuple<int, int> publicKey, string plaintext)
        {
            int key = publicKey.Item1;
            int n = publicKey.Item2;

            int[] cipher = new int[plaintext.Length];
            for (int i = 0; i < plaintext.Length; i++)
            {
                cipher[i] = ModPow(plaintext[i], key, n);
            }

            return cipher;
        }

        static string Decrypt(Tuple<int, int> privateKey, int[] ciphertext)
        {
            int key = privateKey.Item1;
            int n = privateKey.Item2;

            StringBuilder plain = new StringBuilder();
            for (int i = 0; i < ciphertext.Length; i++)
            {
                plain.Append((char)ModPow(ciphertext[i], key, n));
            }

            return plain.ToString();
        }

        static int ModPow(int baseNumber, int exponent, int modulus)
        {
            int result = 1;
            while (exponent > 0)
            {
                if (exponent % 2 == 1)
                {
                    result = (result * baseNumber) % modulus;
                }
                baseNumber = (baseNumber * baseNumber) % modulus;
                exponent /= 2;
            }
            return result;
        }
    }
}
