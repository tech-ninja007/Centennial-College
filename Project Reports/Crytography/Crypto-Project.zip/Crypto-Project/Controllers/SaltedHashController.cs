﻿using Crypto_Project.Models;
using Microsoft.AspNetCore.Mvc;
using System.Security.Cryptography;
using System.Security.Policy;
using System.Text;

namespace Crypto_Project.Controllers
{
    public class SaltedHashController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Index(SaltedHash obj)
        {
            if(ModelState.IsValid)
            {
                SHA256 sha256Hash = SHA256.Create();
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(obj.Text));
                obj.SHAHash = Convert.ToHexString(bytes);
                var hash = HashPasword(obj.Text, out var salt);
                obj.Salt = Convert.ToHexString(salt);
                obj.Hash = hash;
            }
            return View(obj);
        }
        public IActionResult VerifyHash()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult VerifyHash(SaltedHash obj)
        {
            if (ModelState.IsValid)
            {            
                if(VerifyPassword(obj.Text, obj.Hash, Convert.FromHexString(obj.Salt)))
                {
                    ViewData["CheckPass"] = "The Hash matches the text.";
                }
                else
                {
                    ViewData["CheckFail"] = "The Hash doesnot matches the text.";
                }
            }
            return View(obj);
        }
        static string HashPasword(string password, out byte[] salt)
        {
            salt = RandomNumberGenerator.GetBytes(32);

            var hash = Rfc2898DeriveBytes.Pbkdf2(
                Encoding.UTF8.GetBytes(password),
                salt,
                350000,
                HashAlgorithmName.SHA256,
                32);

            return Convert.ToHexString(hash);
        }
        static bool VerifyPassword(string password, string hash, byte[] salt)
        {
            var hashToCompare = Rfc2898DeriveBytes.Pbkdf2(password, salt, 350000, HashAlgorithmName.SHA256, 32);

            return CryptographicOperations.FixedTimeEquals(hashToCompare, Convert.FromHexString(hash));
        }
    }
}
