﻿using Crypto_Project.Models;
using Microsoft.AspNetCore.DataProtection.KeyManagement;
using Microsoft.AspNetCore.Mvc;
using System.Security.Cryptography;
using System.Text;

namespace Crypto_Project.Controllers
{
    public class AESController : Controller
    {
        public IActionResult Encrypt()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Encrypt(AES obj)
        {
            if (ModelState.IsValid)
            {
                var cipher = EncryptAES(obj.Key, obj.Text);
                obj.Cipher = cipher;
            }
            return View(obj);
        }
        public IActionResult Decrypt()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Decrypt(AES obj)
        {
            if (ModelState.IsValid)
            {
                var text = DecryptAES(obj.Key, obj.Cipher);
                obj.Text = text;
            }
            return View(obj);
        }
        static string EncryptAES(string keyInput, string text)
        {
            byte[] key = Encoding.UTF8.GetBytes(keyInput);

            Aes aes = Aes.Create();
            aes.KeySize = 256;
            aes.Mode = CipherMode.CBC;
            aes.Key = key;
            byte[] fixedIV = Encoding.UTF8.GetBytes("1234567890123456");
            aes.IV = fixedIV;
            byte[] ciphertext;

            using (ICryptoTransform encryptor = aes.CreateEncryptor())
            {
                byte[] plaintextBytes = Encoding.UTF8.GetBytes(text);
                ciphertext = encryptor.TransformFinalBlock(plaintextBytes, 0, plaintextBytes.Length);
            }
            return Convert.ToBase64String(ciphertext);

        }
        static string DecryptAES(string keyInput, string text)
        {
            byte[] key = Encoding.UTF8.GetBytes(keyInput);

            Aes aes = Aes.Create();
            aes.KeySize = 256;
            aes.Mode = CipherMode.CBC;
            aes.Key = key;
            byte[] fixedIV = Encoding.UTF8.GetBytes("1234567890123456");
            aes.IV = fixedIV;
            byte[] ciphertext = Convert.FromBase64String(text);
            string decryptedText;
            using (ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV))
            {
                byte[] decryptedBytes = decryptor.TransformFinalBlock(ciphertext, 0, ciphertext.Length);
                decryptedText = Encoding.UTF8.GetString(decryptedBytes);
            }
            return decryptedText;
        }
    }
}
